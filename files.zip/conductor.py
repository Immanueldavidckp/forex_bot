#!/usr/bin/env python3
"""
conductor.py - starts each cycle, waits for the six agents, applies the hard guard,
then hands the order to OpenClaw (or the paper account).

  python3 conductor.py                         # live prices, paper money
  python3 conductor.py --handoff openclaw      # live prices, OpenClaw executes via place_order.py
  python3 conductor.py --mock-data --cycles 5  # fake prices, for testing with agent.py --mock
"""
import argparse, json, os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import place_order as po  # noqa: E402
from claude_trading_desk import guard, handoff  # noqa: E402
from llm_paper_trader import INTERVAL_SEC, MockFeed, fetch_binance, indicators, now  # noqa: E402

ROLES = ["research", "news", "strategy", "code", "risk", "boss"]
CYCLES = os.path.join(HERE, "cycles")


def write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=1)
    os.replace(tmp, path)


def start_cycle(args, candles, n):
    d = os.path.join(CYCLES, time.strftime("%Y%m%d-%H%M%S") + f"-{n:04d}")
    os.makedirs(d)
    price = candles[-1]["c"]
    st = po.load()
    write(os.path.join(d, "account.json"), {"budget_usd": args.budget, "holding": st["position"],
                                             "today_realized_pnl": round(st["day_pnl"], 2)})
    market = {"symbol": args.symbol, "price": round(price, 2), "time": now(),
              "last_24_closes": [round(c["c"], 2) for c in candles[-24:]],
              **{k: round(v, 2) for k, v in indicators(candles).items()}}
    write(os.path.join(d, "market.json"), market)   # this file wakes up research + news
    return d, price, st["position"]


def wait_for_team(d, timeout):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if os.path.exists(os.path.join(d, "boss.json")):
            return True
        time.sleep(2)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="BTC/USDT")
    ap.add_argument("--interval", default="1h", choices=INTERVAL_SEC)
    ap.add_argument("--budget", type=float, default=50)
    ap.add_argument("--handoff", default="paper", choices=["paper", "openclaw"])
    ap.add_argument("--team-timeout", type=int, default=900, help="seconds to wait for the boss")
    ap.add_argument("--cycles", type=int, default=0, help="0 = forever")
    ap.add_argument("--mock-data", action="store_true")
    args = ap.parse_args()

    if args.handoff == "paper":       # paper can never send real orders, whatever desk.env says
        po.LIVE = False
        po.STATE_FILE = os.path.join(po.HERE, "paper_state.json")
    os.makedirs(CYCLES, exist_ok=True)
    feed = MockFeed(7, start=60000) if args.mock_data else None
    print(f"=== CONDUCTOR {args.symbol} every {args.interval}, handoff={args.handoff} ===", flush=True)

    n = 0
    while args.cycles == 0 or n < args.cycles:
        n += 1
        t_start = time.time()
        try:
            candles = feed.get() if feed else fetch_binance(args.symbol.replace("/", ""), args.interval)
        except Exception as e:
            print("data error:", e, flush=True)
            time.sleep(60)
            continue
        if args.handoff == "paper":
            po.check_exits(candles[-1]["h"], candles[-1]["l"])

        d, price, holding = start_cycle(args, candles, n)
        print(f"\n{now()} cycle {os.path.basename(d)} price {price:.2f} - team working...", flush=True)
        order = result = None
        if wait_for_team(d, args.team_timeout):
            reports = {r: json.load(open(os.path.join(d, f"{r}.json"))) for r in ROLES}
            final = guard(reports, price, holding, args.budget)
            if final["action"] in ("buy", "sell"):
                order, result = handoff(final, args.symbol, args.handoff, price)
        else:
            final = {"action": "hold", "why": "team timed out"}
        write(os.path.join(d, "final.json"), {"final": final, "order": order, "result": result})
        open(os.path.join(d, "closed"), "w").close()
        print(f"  DECISION {final['action'].upper()}: {final.get('why', '')[:90]}", flush=True)
        if result:
            print(f"  EXECUTION {result}", flush=True)

        if not args.mock_data:
            time.sleep(max(0, INTERVAL_SEC[args.interval] - (time.time() - t_start)))

    s = po.load()
    print(f"\nrealized P&L {s['total_pnl']:+.2f}  holding {bool(s['position'])}")


if __name__ == "__main__":
    main()
