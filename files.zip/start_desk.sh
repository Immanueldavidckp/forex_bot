#!/usr/bin/env bash
# Opens the whole desk in tmux: 6 Claude Code agents in one window, conductor in another,
# plus the stop-loss watcher when trading through OpenClaw.
#
#   ./start_desk.sh              real Claude agents, paper money
#   ./start_desk.sh paper mock   no Claude calls, fake prices (plumbing test)
#   ./start_desk.sh openclaw     real agents -> OpenClaw -> place_order.py (LIVE only if desk.env has LIVE=1)
#
# Inside tmux: Ctrl+b then n/p to switch windows, Ctrl+b then d to detach (keeps running).
# Stop everything: tmux kill-session -t desk
set -e
cd "$(dirname "$0")"
MODE=${1:-paper}
MOCK=${2:-}
AFLAG=""; CFLAG=""
if [ "$MOCK" = "mock" ]; then AFLAG="--mock"; CFLAG="--mock-data --cycles 20"; fi

tmux kill-session -t desk 2>/dev/null || true
tmux new-session -d -s desk -n team "python3 agent.py research $AFLAG; read"
for r in news strategy code risk boss; do
  tmux split-window -t desk:team "python3 agent.py $r $AFLAG; read"
  tmux select-layout -t desk:team tiled
done
tmux new-window -t desk -n conductor "python3 conductor.py --handoff $MODE $CFLAG; read"
if [ "$MODE" = "openclaw" ]; then
  tmux new-window -t desk -n stops "python3 ../place_order.py watch; read"
fi
tmux select-window -t desk:team
tmux attach -t desk
